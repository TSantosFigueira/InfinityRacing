var searchData=
[
  ['quit',['quit',['../class_quit_manager.html#ad27bb63bb78aa2582eb9892bef4cbd2c',1,'QuitManager']]],
  ['quitmanager',['QuitManager',['../class_quit_manager.html',1,'']]]
];
