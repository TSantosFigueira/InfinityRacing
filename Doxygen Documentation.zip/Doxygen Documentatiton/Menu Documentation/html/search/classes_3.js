var searchData=
[
  ['quitmanager',['QuitManager',['../class_quit_manager.html',1,'']]]
];
