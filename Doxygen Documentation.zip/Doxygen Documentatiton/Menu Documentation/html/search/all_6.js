var searchData=
[
  ['nopressed',['noPressed',['../class_quit_manager.html#adb17be214832f98d8ad9dbc077254f4b',1,'QuitManager']]]
];
